package com.company;
import java.io.*;
import java.util.*;


public class Main {

    public static void main(String[] args) {

        String[][] indata = new String[101135][8];
        int count = 0;
        int inputNumber;
        String countDays="12/34/5678"; //temporary value for counting days

        try {
            // csv data file
            File csv = new File("covid-data.csv");
            BufferedReader br = new BufferedReader(new FileReader(csv));
            br.readLine();  // read first line beforehand and ignore
            String line = "";
            line = br.readLine();
            int row = 1;
            int starti, endi;

            Scanner sc = new Scanner(System.in);
            System.out.print("Choose number to read specific period's data below." +"\n" + "Day 1 ~ Day 111 : Input number [1]" +"\n" + "Day 112 ~ Day 222 : Input number [2]" +"\n"+ "Day 223 ~ Day 333 : Input number [3]" +"\n"+ "Day 334 ~ Day 444 : Input number [4]" +"\n"+ "Day 445 ~ Day 555 : Input number [5]" + "\n" + "Input your number : ");
            inputNumber = sc.nextInt();

            {

                System.out.print("iso_code | "+ "continent | "+"location | "+"date | "+ "new_cases | "+"new_deaths | "+"people_vaccinated | "+"population\n");

                while ((line = br.readLine()) != null) {
                    if (inputNumber == 1) {
                        starti = 0;
                        endi = 111;
                        String[] token = line.split(",", -1);   // -1 means helping reading contents even blank after "," marks.
                        for (int i = 0; i < 8; i++) {
                            indata[row][i] = token[i];
                        }
                        if (count > starti && count <= endi) {
                            for (int i = 0; i < 8; i++) {
                                System.out.print("[" + indata[row - 1][i] + "] ");
                            }
                            System.out.println("");
                            if (count == 112) {
                                break;
                            }
                        }
                    }
                    if (inputNumber == 2) {
                        starti = 111;
                        endi = 222;
                        String[] token = line.split(",", -1);   // -1 means helping reading contents even blank after "," marks.
                        for (int i = 0; i < 8; i++) {
                            indata[row][i] = token[i];
                        }
                        if (count > starti && count <= endi) {
                            for (int i = 0; i < 8; i++) {
                                System.out.print("[" + indata[row - 1][i] + "] ");
                            }
                            System.out.println("");
                            if (count == 223) {
                                break;
                            }
                        }
                    }
                    if (inputNumber == 3) {
                        starti = 222;
                        endi = 333;
                        String[] token = line.split(",", -1);   // -1 means helping reading contents even blank after "," marks.
                        for (int i = 0; i < 8; i++) {
                            indata[row][i] = token[i];
                        }
                        if (count > starti && count <= endi) {
                            for (int i = 0; i < 8; i++) {
                                System.out.print("[" + indata[row - 1][i] + "] ");
                            }
                            System.out.println("");
                            if (count == 334) {
                                break;
                            }
                        }
                    }

                    if (inputNumber == 4) {
                        starti = 333;
                        endi = 444;
                        String[] token = line.split(",", -1);   // -1 means helping reading contents even blank after "," marks.
                        for (int i = 0; i < 8; i++) {
                            indata[row][i] = token[i];
                        }
                        if (count > starti && count <= endi) {
                            for (int i = 0; i < 8; i++) {
                                System.out.print("[" + indata[row - 1][i] + "] ");
                            }
                            System.out.println("");
                            if (count == 445) {
                                break;
                            }
                        }
                    }
                    if (inputNumber == 5) {
                        starti = 444;
                        endi = 555;
                        String[] token = line.split(",", -1);   // -1 means helping reading contents even blank after "," marks.
                        for (int i = 0; i < 8; i++) {
                            indata[row][i] = token[i];
                        }
                        if (count > starti && count <= endi) {
                            for (int i = 0; i < 8; i++) {
                                System.out.print("[" + indata[row - 1][i] + "] ");
                            }
                            System.out.println("");
                            if (count == 556) {
                                break;
                            }
                        }
                    }
                    if (!indata[row][3].equals(countDays)) {
                        count += 1;
                    }
                    countDays = indata[row][3];

                    String[] date = indata[row][3].split("/");

                    row++;
                }
            }

            br.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}







